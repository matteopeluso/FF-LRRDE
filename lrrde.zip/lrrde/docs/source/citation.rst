Citation
========

LRRDE is freely available under the terms of the MIT open-source license.
However, we ask that you properly cite the relevant, underlying work in your published work.
For convenience we provide a list of citations here.

::

        Francesco Fracchia, Gianluca Del Frate, Giordano Mancini, Walter Rocchia, and Vincenzo Barone 
        "Force Field Parametrization of Metal Ions from Statistical Learning Techniques"
        DOI: 10.1021/acs.jctc.7b00779
